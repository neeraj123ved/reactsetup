import { UPDATE_FIELD_AUTH } from '../actionTypes'

const INITIAL_STATE = { activeStep: 0, next: 'Next' }

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case UPDATE_FIELD_AUTH:
      return { ...state, [action.key]: action.value }
    default:
      return state
  }
}
