import superagent from 'superagent'

const API_BASE = process.env.REACT_APP_DEV_API || 'http://172.16.1.174:8080/api'

const responseBody = res => res.body
const errorBody = err => {
  return {
    statusText: err.response.statusText,
    statusCode: err.response.statusCode,
    errors: err.response.body.errors,
    error: true
  }
}

const errorResponse = err => {
  return {
    statusText: err.response.statusText,
    statusCode: err.response.statusCode
  }
}

let token
const setToken = _token => {
  token = _token
  return token
}

const tokenPlugin = req => {
  if (token) {
    req.set('authorization', `Bearer ${token}`)
  }
}

const requests = {
  del: url =>
    superagent
      .del(`${API_BASE}${url}`)
      .use(tokenPlugin)
      .then(responseBody),
  get: url => {
    return superagent
      .get(`${API_BASE}${url}`)
      .use(tokenPlugin)
      .then(responseBody)
  },
  put: (url, body) =>
    superagent
      .put(`${API_BASE}${url}`, body)
      .use(tokenPlugin)
      .then(responseBody),
  post: (url, body) =>
    superagent
      .post(`${API_BASE}${url}`, body)
      .use(tokenPlugin)
      .then(responseBody)
      .catch(errorBody)
}

export const Auth = {
  register: (name, email, password, newsletter, agreedToPrivacy) =>
    requests.post('/users', {
      name,
      email,
      password,
      newsletter,
      agreedToPrivacy
    }),
  login: (email, password) => requests.post('/login', { email, password }),
  current: () => requests.get('/users/me'),
  account: account => requests.post('/accounts', account),
  LogoUrl: (file, id) => {
    return superagent
      .post(`${API_BASE}/accounts/` + id + `/logos`)
      .send(file)
      .use(tokenPlugin)
      .then(responseBody)
  },
  customers: customers => requests.post('/customers', customers),
  customersData: () => requests.get('/customers'),
  lineItems: lineItems => requests.post('/line_items', lineItems),
  lineItemsData: () => requests.get('/line_items'),
  referenceIdData: () => requests.get('/jobs/get_quote_reference'),
  jobs: jobs => requests.post('/jobs', jobs),
  jobsData: () => requests.get('/jobs'),
  jobslineitems: (id, jobslineitems) =>
    requests.post('/jobs/' + id + '/line_items', jobslineitems),
  jobslineitemsData: id => requests.get('/jobs/' + id + '/line_items'),
  convertInvoice: id => requests.put('/jobs/' + id + '/convert_to_invoice'),
  jobArchive: id => requests.put('/jobs/' + id + '/archive'),
  jobAccepted: id => requests.put('/jobs/' + id + '/accept'),
  jobCompleted: id => requests.put('/jobs/' + id + '/complete'),
  getJobs: id => requests.get('/jobs/' + id),
  setJobs: (id, jobs) => requests.put('/jobs/' + id, jobs),
  sendQuote: id => {
    return superagent
      .post(`${API_BASE}/jobs/` + id + `/send_quote`)
      .use(tokenPlugin)
      .then(responseBody)
      .catch(errorResponse)
  },
  sendInvoice: id => {
    return superagent
      .post(`${API_BASE}/jobs/` + id + `/send_invoice`)
      .use(tokenPlugin)
      .then(responseBody)
      .catch(errorResponse)
  }
}

export default { Auth, setToken }
