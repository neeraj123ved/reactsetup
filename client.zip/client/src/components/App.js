import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Switch, Route } from 'react-router-dom'
import { push } from 'react-router-redux'
import { createGenerateClassName } from '@material-ui/core/styles'
import JssProvider from 'react-jss/lib/JssProvider'

import { store } from '../store'
import agent from '../agent'
import ForgetPassword from '../pages/Forgetpassword/ForgetPassword'
import ResetPassword from '../pages/ResetPassword/ResetPassword'
import Login from '../pages/Login/Login'
import Signup from '../pages/Signup/Signup'
import Dashboard from '../pages/Dashboard/Dashboard'
import Boarding from '../pages/Boarding/Boarding'
import NewQuote from '../pages/Dashboard/DashboardPages/NewQuote/NewQuote'
import EditInvoice from '../pages/Dashboard/DashboardPages/EditInvoice/EditInvoice'
import ViewInvoice from '../pages/Dashboard/DashboardPages/ViewInvoice/ViewInvoice'
import ViewQuote from '../pages/Dashboard/DashboardPages/ViewQuote/ViewQuote'
import PreviewQuote from '../pages/Dashboard/DashboardPages/PreviewQuote/PreviewQuote'
import PreviewInvoice from '../pages/Dashboard/DashboardPages/PreviewInvoice/PreviewInvoice'
import Customers from '../pages/Dashboard/DashboardPages/Customers/Customers'
import JobItems from '../pages/Dashboard/DashboardPages/JobItems/JobItems'
import Settings from '../pages/Dashboard/DashboardPages/Settings/Settings'
import SetupPayments from '../pages/Dashboard/DashboardPages/SetupPayments/SetupPayments'
import { PrivateRoute } from './PrivateRoute'
import Home from '../pages/Home'
import { APP_LOAD, REDIRECT } from '../actionTypes'

const mapStateToProps = state => {
  return {
    appLoaded: state.common.appLoaded,
    redirectTo: state.common.redirectTo,
    currentUser: state.common.currentUser
  }
}

const mapDispatchToProps = dispatch => ({
  onLoad: (payload, token) =>
    dispatch({ type: APP_LOAD, payload, token, skipTracking: true }),
  onRedirect: () => dispatch({ type: REDIRECT })
})

const generateClassName = createGenerateClassName({
  dangerouslyUseGlobalCSS: true,
  productionPrefix: 'c'
})

class App extends Component {
  componentWillReceiveProps(nextProps) {
    // Setup to support auto redirecting on e.g. already autheticated user
    if (nextProps.redirectTo) {
      store.dispatch(push(nextProps.redirectTo))
      this.props.onRedirect()
    }
  }
  componentWillMount() {
    if (localStorage.getItem('jwt')) {
      agent.setToken(localStorage.getItem('jwt'))
    } else {
      this.props.history.push('/')
    }
  }
  render() {
    return (
      <JssProvider generateClassName={generateClassName}>
        <Switch>
          <PrivateRoute exact path="/" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/signup" component={Signup} />
          <Route path="/forgetpassword" component={ForgetPassword} />
          <Route path="/resetpassword" component={ResetPassword} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/new_quote/" component={NewQuote} />
          <Route path="/edit_invoice/:id" component={EditInvoice} />
          <Route path="/view_quote/:id" component={ViewQuote} />
          <Route path="/view_invoice/:id" component={ViewInvoice} />
          <Route path="/update_quote/:id/" component={NewQuote} />
          <Route path="/requote/:id/" component={NewQuote} />
          <Route path="/jobs/:id/preview_quote" component={PreviewQuote} />
          <Route path="/onboarding" component={Boarding} />
          <Route path="/preview_invoice/:id" component={PreviewInvoice} />
          <Route path="/customers" component={Customers} />
          <Route path="/jobitems" component={JobItems} />
          <Route path="/settings" component={Settings} />
          <Route path="/setup_payments" component={SetupPayments} />
        </Switch>
      </JssProvider>
    )
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)
