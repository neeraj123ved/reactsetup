import auth from './reducers/auth'
import common from './reducers/common'
import dashboard from './reducers/dashboard'
import boarding from './reducers/boarding'
import { routerReducer } from 'react-router-redux'
import { combineReducers } from 'redux'
import { reducer as formReducer } from 'redux-form'

export default combineReducers({
  auth,
  common,
  dashboard,
  boarding,
  router: routerReducer,
  form: formReducer
})
